#include <iostream>
using namespace std;

// Q3
bool MarkovMatrix(float **arr, int rows, int columns)
{
    bool check = true;
    for (int i = 0; i < rows; i++)
    {
        float sum = 0;
        for (int j = 0; j < columns; j++)
        {
            sum += arr[i][j];
        }
        if (sum != 1)
        {
            check = false;
            return check;
        }
    }
    return check;
}