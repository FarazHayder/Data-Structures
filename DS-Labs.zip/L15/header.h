#include <iostream>
#include <stack>
#include <conio.h>

using namespace std;

// Forward declarations
struct Edge;
struct Node;

// Edge structure
struct Edge
{
    int length;
    Node *destination;
    Edge *next;

    Edge(Node *dest, int len);
};

// Node structure
struct Node
{
    int id;
    Node *next;
    Edge *edges;

    Node(int locationID);
};

// RouteOptimizationSystem class
class RouteOptimizationSystem
{
private:
    Node *head;

public:
    RouteOptimizationSystem();

    // Function to add a location to the route optimization system
    void addLocation(int locationID);

    // Function to add a route between two locations with a specified length
    void addRoute(int source, int destination, int length);

    // Function to find the shortest path between two locations using Dijkstra's algorithm
    void findShortestPath(int start, int end);
};