#include <iostream>
#include <fstream>
#include <sstream>
#include "MyVectorImplementation.h"
#include <conio.h>
#include <iomanip>

using namespace std;
struct Student
{
    int ser;
    string Reg;
    string R_N;
    string name;
    int A1, A2, A3, A4;
    float As, S1, S2, P1, P2, F1, F2;
    float mid1, mid2, gtot;
    char grade;
};

template <typename T>
class Stack
{
private:
    MyVector<T> elements;

public:
    void push(T value)
    {
        elements.addElement(value);
    }

    void pop()
    {
        if (!elements.empty())
        {
            elements.removeElement();
        }
        else
        {
            cerr << "Stack is empty. Cannot pop.\n";
        }
    }

    T peek()
    {
        if (!elements.empty())
        {
            return elements.back();
        }
        else
        {
            cerr << "Stack is empty. No top element.\n";
            return T();
        }
    }

    bool isEmpty() const
    {
        return elements.empty();
    }

    MyVector<T> getElements() const
    {
        return elements;
    }
};

void loadCSVData(const string &filename, Stack<Student> &studentStack);
void transferStackToVector(Stack<Student> &studentStack, MyVector<Student> &stdData);
void displayStudentData(const MyVector<Student> &stdData);
void sortByR_N(MyVector<Student> &stdData);
void sortByName(MyVector<Student> &stdData);
void sortByA1(MyVector<Student> &stdData);
void Continue();

void loadCSVData(const string &filename, Stack<Student> &studentStack)
{
    ifstream file(filename);
    string line;
    getline(file, line);

    while (getline(file, line))
    {
        stringstream ss(line);
        Student student;
        char delim;

        ss >> student.ser >> delim;
        getline(ss, student.Reg, delim);
        getline(ss, student.R_N, delim);
        getline(ss, student.name, delim);
        ss >> student.A1 >> delim >> student.A2 >> delim >> student.A3 >> delim >> student.A4 >> delim >> student.As >> delim;
        ss >> student.S1 >> delim >> student.S2 >> delim >> student.P1 >> delim >> student.P2 >> delim;
        ss >> student.F1 >> delim >> student.F2 >> delim >> student.mid1 >> delim >> student.mid2 >> delim;
        ss >> student.gtot >> delim >> student.grade;

        studentStack.push(student);
    }
}

void transferStackToVector(Stack<Student> &studentStack, MyVector<Student> &stdData)
{
    MyVector<Student> temp = studentStack.getElements();
    while (!temp.empty())
    {
        stdData.addElement(temp.back());
        temp.removeElement();
    }
}
void transferVectorToStack(MyVector<Student> &stdData, Stack<Student> &studentStack)
{
    for (size_t i = 0; i < stdData.elements; ++i)
    {
        studentStack.push(stdData.getElementAt(i));
    }
}

void saveStackToCSV(const string &filename, Stack<Student> &studentStack)
{
    ofstream file(filename);
    file << "Sr.#,RegDt.,RollNo,Name,As:1,As:2,As:3,As:4,As,S-I:1,S-I,Proj:1,Proj,Final:1,Final,Mid:1,Mid,G.Tot,Grade\n";

    Stack<Student> tempStack = studentStack;

    while (!tempStack.isEmpty())
    {
        Student student = tempStack.peek();
        tempStack.pop();

        file << student.ser << "," << student.Reg << "," << student.R_N << "," << student.name << ",";
        file << student.A1 << "," << student.A2 << "," << student.A3 << "," << student.A4 << "," << student.As << ",";
        file << student.S1 << "," << student.S2 << "," << student.P1 << "," << student.P2 << "," << student.F1 << ",";
        file << student.F2 << "," << student.mid1 << "," << student.mid2 << "," << student.gtot << "," << student.grade << "\n";
    }

    file.close();
}

void displayStudentData(MyVector<Student> &stdData)
{
    // For clearing console screen
    system("cls");
    // Printing the attributes
    // cout << left << setw(5) << "Sr.#";
    cout << left << setw(8) << "RegDt.";
    cout << left << setw(9) << "RollNo";
    cout << left << setw(17) << "Name";
    cout << left << setw(8) << "As:1";
    cout << left << setw(6) << "As:2";
    cout << left << setw(6) << "As:3";
    cout << left << setw(6) << "As:4";
    cout << left << setw(6) << "As";
    cout << left << setw(6) << "S-I:1";
    cout << left << setw(6) << "S-I";
    cout << left << setw(7) << "Proj:1";
    cout << left << setw(6) << "Proj";
    cout << left << setw(8) << "Final:1";
    cout << left << setw(6) << "Final";
    cout << left << setw(6) << "Mid:1";
    cout << left << setw(6) << "Mid";
    cout << left << setw(8) << "G.Tot";
    cout << left << setw(6) << "Grade" << endl
         << endl;
    for (int i = 0; i < stdData.elements; ++i)
    {
        Student &student = stdData[i];
        // cout << left << setw(5) << student.ser;
        cout << left << setw(8) << student.Reg;
        cout << left << setw(9) << student.R_N;
        cout << left << setw(17) << student.name;
        cout << left << setw(8) << student.A1;
        cout << left << setw(6) << student.A2;
        cout << left << setw(6) << student.A3;
        cout << left << setw(6) << student.A4;
        cout << left << setw(6) << student.As;
        cout << left << setw(6) << student.S1;
        cout << left << setw(6) << student.S2;
        cout << left << setw(7) << student.P1;
        cout << left << setw(6) << student.P2;
        cout << left << setw(8) << student.F1;
        cout << left << setw(6) << student.F2;
        cout << left << setw(6) << student.mid1;
        cout << left << setw(6) << student.mid2;
        cout << left << setw(8) << student.gtot;
        cout << left << setw(6) << student.grade << endl;
    }
    Continue();
}

void sortByR_N(MyVector<Student> &stdData)
{
    for (int i = 0; i < stdData.elements - 1; ++i)
    {
        for (int j = 0; j < stdData.elements - i - 1; ++j)
        {
            if (stdData[j].R_N < stdData[j + 1].R_N)
            {
                swap(stdData[j], stdData[j + 1]);
            }
        }
    }
}

void sortByName(MyVector<Student> &stdData)
{
    for (int i = 0; i < stdData.elements - 1; ++i)
    {
        for (int j = 0; j < stdData.elements - i - 1; ++j)
        {
            if (stdData[j].name < stdData[j + 1].name)
            {
                swap(stdData[j], stdData[j + 1]);
            }
        }
    }
}

void sortByA1(MyVector<Student> &stdData)
{
    for (int i = 0; i < stdData.elements - 1; ++i)
    {
        for (int j = 0; j < stdData.elements - i - 1; ++j)
        {
            if (stdData[j].A1 < stdData[j + 1].A1)
            {
                swap(stdData[j], stdData[j + 1]);
            }
        }
    }
}

void sortByA2(MyVector<Student> &stdData)
{
    for (int i = 0; i < stdData.elements - 1; ++i)
    {
        for (int j = 0; j < stdData.elements - i - 1; ++j)
        {
            if (stdData[j].A2 < stdData[j + 1].A2)
            {
                swap(stdData[j], stdData[j + 1]);
            }
        }
    }
}

void sortByA3(MyVector<Student> &stdData)
{
    for (int i = 0; i < stdData.elements - 1; ++i)
    {
        for (int j = 0; j < stdData.elements - i - 1; ++j)
        {
            if (stdData[j].A3 < stdData[j + 1].A3)
            {
                swap(stdData[j], stdData[j + 1]);
            }
        }
    }
}

void sortByA4(MyVector<Student> &stdData)
{
    for (int i = 0; i < stdData.elements - 1; ++i)
    {
        for (int j = 0; j < stdData.elements - i - 1; ++j)
        {
            if (stdData[j].A4 < stdData[j + 1].A4)
            {
                swap(stdData[j], stdData[j + 1]);
            }
        }
    }
}

void sortByAs(MyVector<Student> &stdData)
{
    for (int i = 0; i < stdData.elements - 1; ++i)
    {
        for (int j = 0; j < stdData.elements - i - 1; ++j)
        {
            if (stdData[j].As < stdData[j + 1].As)
            {
                swap(stdData[j], stdData[j + 1]);
            }
        }
    }
}

void sortByS1(MyVector<Student> &stdData)
{
    for (int i = 0; i < stdData.elements - 1; ++i)
    {
        for (int j = 0; j < stdData.elements - i - 1; ++j)
        {
            if (stdData[j].S1 < stdData[j + 1].S1)
            {
                swap(stdData[j], stdData[j + 1]);
            }
        }
    }
}

void sortByS2(MyVector<Student> &stdData)
{
    for (int i = 0; i < stdData.elements - 1; ++i)
    {
        for (int j = 0; j < stdData.elements - i - 1; ++j)
        {
            if (stdData[j].S2 < stdData[j + 1].S2)
            {
                swap(stdData[j], stdData[j + 1]);
            }
        }
    }
}

void sortByP1(MyVector<Student> &stdData)
{
    for (int i = 0; i < stdData.elements - 1; ++i)
    {
        for (int j = 0; j < stdData.elements - i - 1; ++j)
        {
            if (stdData[j].P1 < stdData[j + 1].P1)
            {
                swap(stdData[j], stdData[j + 1]);
            }
        }
    }
}

void sortByP2(MyVector<Student> &stdData)
{
    for (int i = 0; i < stdData.elements - 1; ++i)
    {
        for (int j = 0; j < stdData.elements - i - 1; ++j)
        {
            if (stdData[j].P2 < stdData[j + 1].P2)
            {
                swap(stdData[j], stdData[j + 1]);
            }
        }
    }
}

void sortByF1(MyVector<Student> &stdData)
{
    for (int i = 0; i < stdData.elements - 1; ++i)
    {
        for (int j = 0; j < stdData.elements - i - 1; ++j)
        {
            if (stdData[j].A4 < stdData[j + 1].A4)
            {
                swap(stdData[j], stdData[j + 1]);
            }
        }
    }
}

void sortByF2(MyVector<Student> &stdData)
{
    for (int i = 0; i < stdData.elements - 1; ++i)
    {
        for (int j = 0; j < stdData.elements - i - 1; ++j)
        {
            if (stdData[j].F2 < stdData[j + 1].A4)
            {
                swap(stdData[j], stdData[j + 1]);
            }
        }
    }
}

void sortBymid1(MyVector<Student> &stdData)
{
    for (int i = 0; i < stdData.elements - 1; ++i)
    {
        for (int j = 0; j < stdData.elements - i - 1; ++j)
        {
            if (stdData[j].A4 < stdData[j + 1].A4)
            {
                swap(stdData[j], stdData[j + 1]);
            }
        }
    }
}

void sortBymid2(MyVector<Student> &stdData)
{
    for (int i = 0; i < stdData.elements - 1; ++i)
    {
        for (int j = 0; j < stdData.elements - i - 1; ++j)
        {
            if (stdData[j].mid2 < stdData[j + 1].mid2)
            {
                swap(stdData[j], stdData[j + 1]);
            }
        }
    }
}

void sortBygtot(MyVector<Student> &stdData)
{
    for (int i = 0; i < stdData.elements - 1; ++i)
    {
        for (int j = 0; j < stdData.elements - i - 1; ++j)
        {
            if (stdData[j].gtot < stdData[j + 1].gtot)
            {
                swap(stdData[j], stdData[j + 1]);
            }
        }
    }
}

void sortBygrade(MyVector<Student> &stdData)
{
    for (int i = 0; i < stdData.elements - 1; ++i)
    {
        for (int j = 0; j < stdData.elements - i - 1; ++j)
        {
            if (stdData[j].grade < stdData[j + 1].grade)
            {
                swap(stdData[j], stdData[j + 1]);
            }
        }
    }
}

void Continue()
{
    cout << "\nPress any key to continue...";
    getch();
    system("cls");
}