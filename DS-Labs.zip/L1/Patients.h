#ifndef Patients
#define Patients

#include <iostream>
using namespace std;

class Patient
{
    string name;
    string type;
    int numberOfDays;

public:
    Patient()
    {
        name = "";
        type = "";
        numberOfDays = 1;
    }

    Patient(string name, string type, int numberOfDays)
    {
        this->name = name;
        this->type = type;
        this->numberOfDays = numberOfDays;
    }

    // setters and getters
    void setName(string name)
    {
        this->name = name;
    }
    string getName()
    {
        return name;
    }
    void setType(string type)
    {
        this->type = type;
    }
    string getType()
    {
        return type;
    }
    void setNumberOfDays(int numberOfDays)
    {
        this->numberOfDays = numberOfDays;
    }
    int getNumberOfDays()
    {
        return numberOfDays;
    }
};
#endif