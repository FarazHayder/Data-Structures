#if !defined(header)
#define header

#include <iostream>
#include <conio.h>
using namespace std;

class DoubleListNode
{
public:
    int data;
    DoubleListNode *next;
    DoubleListNode *prev;
};
class DoubleList
{
private:
    DoubleListNode *head;
    DoubleListNode *tail;

public:
    DoubleList()
    {
        head = NULL;
        tail = NULL;
    }
    void MainMenu();
    void MainMenuLink();
    void Display()
    {
        DoubleListNode *p = head;
        while (p != NULL)
        {
            cout << p->data << " ";
            p = p->next;
        }
        cout << endl;

        MainMenuLink();
    }
    void InsertAtEnd()
    {
        DoubleListNode *newNode = new DoubleListNode;
        cout << "Enter data: ";
        cin >> newNode->data;
        newNode->next = NULL;
        if (head == NULL)
        {
            newNode->prev = NULL;
            head = newNode;
            tail = newNode;
            MainMenuLink();
            return;
        }
        newNode->prev = tail;
        newNode->prev->next = newNode;
        tail = newNode;
        MainMenuLink();
    }
    void InsertAtBeginning()
    {
        DoubleListNode *newNode = new DoubleListNode;
        cout << "Enter data: ";
        cin >> newNode->data;
        newNode->prev = NULL;
        if (head == NULL)
        {
            newNode->next = NULL;
            head = newNode;
            tail = newNode;
            MainMenuLink();
            return;
        }
        newNode->next = head;
        newNode->next->prev = newNode;
        head = newNode;
        MainMenuLink();
    }
    void InsertBefore()
    {
        DoubleListNode *newNode = new DoubleListNode;
        cout << "Enter data: ";
        cin >> newNode->data;
        int position = -1;
        while (position < 0)
        {
            cout << "Enter position: ";
            cin >> position;
        }
        DoubleListNode *current = head;
        int count = 0;
        while (current != NULL)
        {
            if (count == position)
            {
                if (current == head)
                {
                    InsertAtBeginning();
                    return;
                }
                else
                {
                    newNode->prev = current->prev;
                    newNode->next = current;
                    newNode->next->prev = newNode;
                    newNode->prev->next = newNode;
                    return;
                }
            }
            current = current->next;
            count++;
        }
        cout << "Index out of Bounds!" << endl;

        MainMenuLink();
    }
    void InsertAfter()
    {
        DoubleListNode *newNode = new DoubleListNode;
        cout << "Enter data: ";
        cin >> newNode->data;
        int position = -1;
        while (position < 0)
        {
            cout << "Enter position: ";
            cin >> position;
        }
        DoubleListNode *current = head;
        int count = 0;
        while (current != NULL)
        {
            if (count == position)
            {
                if (current == tail)
                {
                    InsertAtEnd();
                    return;
                }
                else
                {
                    newNode->prev = current;
                    newNode->next = current->next;
                    newNode->next->prev = newNode;
                    newNode->prev->next = newNode;
                    return;
                }
            }
            current = current->next;
            count++;
        }
        cout << "Index out of Bounds!" << endl;

        MainMenuLink();
    }
    void DeleteFirst()
    {
        DoubleListNode *toDelete = head;
        head = head->next;
        head->prev = NULL;
        delete toDelete;

        MainMenuLink();
    }
    void DeleteMiddle()
    {
        DoubleListNode *toDelete = head;
        int size = 0;
        while (toDelete != NULL)
        {
            size++;
            toDelete = toDelete->next;
        }
        size /= 2;
        toDelete = head;
        for (int i = 0; i < size; i++)
        {
            toDelete = toDelete->next;
        }
        toDelete->prev->next = toDelete->next;
        toDelete->next->prev = toDelete->prev;
        delete toDelete;

        MainMenuLink();
    }
    void DeleteLast()
    {
        DoubleListNode *toDelete = tail;
        tail = tail->prev;
        tail->next = NULL;
        delete toDelete;

        MainMenuLink();
    }
    void DeleteAt()
    {
        int position = -1;
        while (position < 0)
        {
            cout << "Enter position: ";
            cin >> position;
        }
        DoubleListNode *toDelete = head;
        int count = 0;
        while (toDelete != NULL)
        {
            if (count == position)
            {
                if (toDelete == head)
                {
                    DeleteFirst();
                    return;
                }
                else if (toDelete == tail)
                {
                    DeleteLast();
                    return;
                }
                else
                {
                    toDelete->prev->next = toDelete->next;
                    toDelete->next->prev = toDelete->prev;
                    delete toDelete;
                    return;
                }
            }
            toDelete = toDelete->next;
            count++;
        }
        cout << "Index out of Bounds!" << endl;

        MainMenuLink();
    }
    void SortList()
    {
        DoubleListNode *outer = head;
        while (outer != NULL)
        {
            DoubleListNode *inner = outer->next;
            while (inner != NULL)
            {
                if (outer->data > inner->data)
                {
                    int temp = outer->data;
                    outer->data = inner->data;
                    inner->data = temp;
                }
                inner = inner->next;
            }
            outer = outer->next;
        }

        MainMenuLink();
    }
    void RemoveDuplicates()
    {
        DoubleListNode *outer = head;
        while (outer != NULL)
        {
            DoubleListNode *inner = outer->next;
            while (inner != NULL)
            {
                if (outer->data == inner->data)
                {
                    if (inner == tail)
                    {
                        DoubleListNode *toDelete = tail;
                        tail = tail->prev;
                        tail->next = NULL;
                        delete toDelete;
                    }
                    else
                    {
                        DoubleListNode *toDelete = inner;
                        inner->prev->next = inner->next;
                        inner->next->prev = inner->prev;
                        delete toDelete;
                        break;
                    }
                }
                inner = inner->next;
            }
            outer = outer->next;
        }

        MainMenuLink();
    }
};

void DoubleList::MainMenu()
{
    // For clearing console screen
    system("cls");
    char option;
    cout << "\n<===================== Main Menu =====================>" << endl
         << "\nPress '1' to 'Display All Elements'" << endl
         << "Press '2' to 'Insert Element at End'" << endl
         << "Press '3' to 'Insert Element at Beginning'" << endl
         << "Press '4' to 'Insert Element before a Node'" << endl
         << "Press '5' to 'Insert Element after a Node'" << endl
         << "Press '6' to 'Delete the First Node'" << endl
         << "Press '7' to 'Delete the Middle Node'" << endl
         << "Press '8' to 'Delete the Last Node'" << endl
         << "Press '9' to 'Delete a Specific Node'" << endl
         << "Press 'a' to 'Sort List'" << endl
         << "Press 'b' to 'Remove Duplicates'" << endl
         << "Press 'c' to 'Exit'" << endl;
    option = getch();

    while (!(option == '1' || option == '2' || option == '3' || option == '4' || option == '5' || option == '6' || option == '7' || option == '8' || option == '9' || option == 'a' || option == 'b' || option == 'c'))
    {
        option = getch();
    }

    switch (option)
    {
    case '1':
        // For clearing console screen
        system("cls");
        Display();
        break;

    case '2':
        // For clearing console screen
        system("cls");
        InsertAtEnd();
        break;

    case '3':
        // For clearing console screen
        system("cls");
        InsertAtBeginning();
        break;

    case '4':
        // For clearing console screen
        system("cls");
        InsertBefore();
        break;

    case '5':
        // For clearing console screen
        system("cls");
        InsertAfter();
        break;

    case '6':
        // For clearing console screen
        system("cls");
        DeleteFirst();
        break;

    case '7':
        // For clearing console screen
        system("cls");
        DeleteMiddle();
        break;

    case '8':
        // For clearing console screen
        system("cls");
        DeleteLast();
        break;

    case '9':
        // For clearing console screen
        system("cls");
        DeleteAt();
        break;

    case 'a':
        // For clearing console screen
        system("cls");
        SortList();
        break;

    case 'b':
        // For clearing console screen
        system("cls");
        RemoveDuplicates();
        break;

    case 'c':
        // For clearing console screen
        system("cls");
        exit(0);
        break;
    }
    MainMenu();
}
// Provides a link to the Main Menu
void DoubleList::MainMenuLink()
{
    char ch;
    cout << "\nPress 'Esc' to 'Go Back' or press 'Enter' to continue to 'Main Menu'" << endl;
    ch = getch();
    while (ch != '\x1B' && ch != '\r')
    {
        ch = getch();
    }
    if (ch == '\r')
    {
        // For clearing console screen
        system("cls");
        MainMenu();
    }
    // For clearing console screen
    system("cls");
}

#endif // header
