#include "Hospitals.h"
#include "Patients.h"

int main() {

	Patient patient1("XYZ", "in-patient", 5);
	Hospital Al_Shifa(&patient1, 10000, 100, 20000);
	if (patient1.getType() == "in-patient") {
		Al_Shifa.totalChargesOfPatient(10000,100,20000);
	}
	if (patient1.getType() == "out-patient") {
		Al_Shifa.totalChargesOfPatient(10000,20000);
	}
	cout << Al_Shifa.getHospitalCharges();

	return 0;
}