#include <iostream>
using namespace std;

// Q2
int **Find(char **arr, int rows, int columns, char *word)
{
    // Creating array to store indices
    int **indices = new int *[2];
    for (int i = 0; i < 2; i++)
    {
        indices[i] = new int[3];
    }
    int iterateIndicesColumn = 0;
    for (int i = 0; i < rows; i++)
    {
        for (int j = 0; j < columns; j++)
        {
            for (int k = 0; k < 3; k++)
            {
                if (arr[i][j] == word[k])
                {
                    indices[0][iterateIndicesColumn] = i;
                    indices[1][iterateIndicesColumn] = j;
                    iterateIndicesColumn++;
                }
            }
        }
    }
    return indices;
}