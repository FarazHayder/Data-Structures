#ifndef Hospitals
#define Hospitals

#include <iostream>
#include "Patients.h"
using namespace std;

class Hospital
{
    Patient *patient;
    int meditationCharges;
    double dailyRate;
    int hospitalCharges;

public:
    Hospital()
    {
        patient = new Patient();
        meditationCharges = 0;
        dailyRate = 0.0;
        hospitalCharges = 0;
    }

    Hospital(Patient* patient, int meditationCharges, double dailyRate, int hospitalCharges)
    {
        this->meditationCharges = meditationCharges;
        this->dailyRate = dailyRate;
        this->hospitalCharges = hospitalCharges;
        this->patient = patient;
    }

    // setters and getters
    void setHospitalCharges(int hospitalCharges)
    {
        this->hospitalCharges = hospitalCharges;
    }
    int getHospitalCharges()
    {
        return hospitalCharges;
    }
    void setDailyRate(double dailyRate)
    {
        this->dailyRate = dailyRate;
    }
    double getDailyRate()
    {
        return dailyRate;
    }
    void setMeditationCharges(int meditationCharges)
    {
        this->meditationCharges = meditationCharges;
    }
    int getMeditationCharges()
    {
        return meditationCharges;
    }

    // Functions
    double totalChargesOfPatient(int meditationCharges, double dailyRate, int hospitalCharges)
    {
        double totalCharges = meditationCharges * dailyRate * hospitalCharges * patient->getNumberOfDays();
        return totalCharges;
    }
    double totalChargesOfPatient(int meditationCharges, int hospitalCharges)
    {
        double totalCharges = meditationCharges * hospitalCharges;
        return totalCharges;
    }
};
#endif