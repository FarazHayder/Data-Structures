#include <iostream>
#include "header.h"
using namespace std;

int main()
{
    BinaryTree avlTree;

    // Insert nodes into the AVL tree
    avlTree.root = avlTree.Insert(50, avlTree.root);
    avlTree.root = avlTree.Insert(30, avlTree.root);
    avlTree.root = avlTree.Insert(70, avlTree.root);
    avlTree.root = avlTree.Insert(20, avlTree.root);
    avlTree.root = avlTree.Insert(40, avlTree.root);
    avlTree.root = avlTree.Insert(60, avlTree.root);
    avlTree.root = avlTree.Insert(80, avlTree.root);

    // Find values in the AVL tree
    avlTree.findValue(30); // Should print "found 30"
    avlTree.findValue(55); // Should print "value 55 not found"

    // Delete a node from the AVL tree
    avlTree.deleteNode(30);

    // Find the deleted node
    avlTree.findValue(30); // Should print "value 30 not found"

    return 0;
}
