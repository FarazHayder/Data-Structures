#include <iostream>
using namespace std;

// avl from bst
struct Node
{
    int value;
    int height;
    Node *left;
    Node *right;

    Node() : value(0), height(0), left(NULL), right(NULL) {}
};

struct BinaryTree
{
    Node *root;

    BinaryTree() : root(nullptr) {}

    int Height(Node *p)
    {
        if (p == NULL)
            return -1;
        else
            return p->height;
    }

    // Function to find the maximum value between two numbers
    int Max(int num1, int num2)
    {
        if (num1 > num2)
        {
            return num1;
        }
        else
        {
            return num2;
        }
    }

    Node *SingleRotateWithRight(Node *K1)
    {
        Node *K2;
        K2 = K1->right; // K1: node whose balance factor is violated
        K1->right = K2->left;
        K2->left = K1;
        K1->height = Max(Height(K1->left), Height(K1->right)) + 1;
        K2->height = Max(Height(K2->right), K1->height) + 1;
        return K2; /* New root */
    }

    Node *SingleRotateWithLeft(Node *K1)
    {
        Node *K2;
        K2 = K1->left; // K1: node whose balance factor is violated
        K1->left = K2->right;
        K2->right = K1;
        K1->height = Max(Height(K1->left), Height(K1->right)) + 1;
        K2->height = Max(Height(K2->left), K1->height) + 1;
        return K2; /* New root */
    }

    Node *DoubleRotateWithLeft(Node *K3)
    {
        /* LL rotation between K1 and K2 */
        K3->left = SingleRotateWithRight(K3->left);
        /* RR rotation between K3 and K2 */
        return SingleRotateWithLeft(K3);
    }
    Node *DoubleRotateWithRight(Node *K1)
    {
        /* RR rotation between K3 and K2 */
        K1->right = SingleRotateWithLeft(K1->right);
        /* LL rotation between K1 and K2 */
        return SingleRotateWithRight(K1);
    }

    Node *Insert(int X, Node *T)
    {
        if (T == NULL)
        { /* Create and return a one-node tree */
            T = new Node();
            T->value = X;
            T->left = T->right = NULL;
        }
        else if (X < T->value)
        {
            T->left = Insert(X, T->left);
            if (Height(T->left) - Height(T->right) == 2)
                if (X < T->left->value)
                    T = SingleRotateWithLeft(T); // RR rotation
                else
                    T = DoubleRotateWithLeft(T); // RL rotation
        }
        else if (X > T->value)
        {
            T->right = Insert(X, T->right);
            if (Height(T->right) - Height(T->left) == 2)
                if (X > T->right->value)
                    T = SingleRotateWithRight(T); // LL rotation
                else
                    T = DoubleRotateWithRight(T); // LR rotation
        }                                         /* Else X is in the tree already; we'll do nothing */
        T->height = Max(Height(T->left), Height(T->right)) + 1;
        return T;
    }

    bool findValue(int num)
    {
        Node *currNode = root;
        bool result = false;

        while (currNode != nullptr)
        {
            if (currNode->value == num)
            {
                cout << "found " << num << endl;
                result = true;
                break;
            }
            else if (num > currNode->value)
            {
                currNode = currNode->right;
            }
            else if (num < currNode->value)
            {
                currNode = currNode->left;
            }
        }

        if (result == false)
        {
            cout << "value" << num << " not found " << endl;
        }
        return result;
    }

    void makedeletion(int num, Node *&nodePtr)
    {
        if (nodePtr == nullptr)
        {
            return;
        }

        if (num < nodePtr->value)
        {
            makedeletion(num, nodePtr->left);
        }
        else if (num > nodePtr->value)
        {
            makedeletion(num, nodePtr->right);
        }
        else
        {
            if (nodePtr->left == nullptr)
            {
                Node *tempNode = nodePtr;
                nodePtr = nodePtr->right;
                delete tempNode;
            }
            else if (nodePtr->right == nullptr)
            {
                Node *tempNode = nodePtr;
                nodePtr = nodePtr->left;
                delete tempNode;
            }
            else
            {
                Node *tempNode = nodePtr->right;
                while (tempNode->left != nullptr)
                {
                    tempNode = tempNode->left;
                }
                nodePtr->value = tempNode->value;
                makedeletion(tempNode->value, nodePtr->right);
            }
        }
    }

    void deleteNode(int num)
    {
        makedeletion(num, root);
    }

    void remove(int num)
    {
        deleteNode(num);
    }
};