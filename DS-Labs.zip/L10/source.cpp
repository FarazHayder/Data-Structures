#include "header.h"

int main()
{

    IntBinaryTree tree;
    tree.insertNode(3);
    tree.insertNode(0);
    tree.insertNode(7);
    // tree.insertNode(4);
    // tree.insertNode(5);

    int count = tree.totalSmallerValues(5);
    cout << "Count: " << count;
    // tree.MainMenu();

    return 0;
}