#include <iostream>
using namespace std;

// Q1
class sortingAlgo
{
    int **arr;
    int rows;
    int columns;

public:
    // Setter
    void setArr(int **arr, int rows, int columns)
    {
        this->arr = arr;
        this->rows = rows;
        this->columns = columns;
    }
    // Function to print the array
    void print()
    {
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < columns; j++)
            {
                cout << arr[i][j] << " ";
            }
            cout << endl;
        }
    }
    // function to swap the the position of two elements
    void swap(int *a, int *b)
    {
        int temp = *a;
        *a = *b;
        *b = temp;
    }
    void sort()
    {
        for (int i = 0; i < rows; i++)
        {
            if (i == 0)
            {
                insertionSort();
            }
            if (i == 1)
            {
                selectionSort();
            }
            if (i == 2)
            {
                bubbleSort();
            }
        }
    }
    void insertionSort()
    {
        for (int i = 1; i < columns; i++)
        {
            int key = arr[0][i];
            int j = i - 1;
            while (key < arr[0][j] && j >= 0)
            {
                arr[0][j + 1] = arr[0][j];
                --j;
            }
            arr[0][j + 1] = key;
        }
    }
    void selectionSort()
    {
        for (int i = 0; i < columns - 1; i++)
        {
            int minIndex = i;
            for (int j = i + 1; j < columns; j++)
            {
                if (arr[1][j] < arr[1][minIndex])
                    minIndex = j;
            }
            swap(&arr[1][minIndex], &arr[1][i]);
        }
    }
    void bubbleSort()
    {
        for (int i = 0; i < (columns - 1); ++i)
        {
            int swapped = 0;
            for (int j = 0; j < (columns - i - 1); ++j)
            {
                if (arr[2][j] > arr[2][j + 1])
                {
                    int temp = arr[2][j];
                    arr[2][j] = arr[2][j + 1];
                    arr[2][j + 1] = temp;
                    swapped = 1;
                }
            }
            if (swapped == 0)
                break;
        }
    }
};