#include "header.h"

int main()
{

    DoubleList List;
    List.MainMenu();

    return 0;
}