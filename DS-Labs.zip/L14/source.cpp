#include <iostream>
#include <queue>
#include <climits>
using namespace std;

struct EdgeNode
{
    int dest;
    int weight;
    EdgeNode *next;

    EdgeNode(int d, int w) : dest(d), weight(w), next(nullptr) {}
};

class Edge
{
public:
    int vertex;
    EdgeNode *head;
    Edge() {}
    Edge(int v) : vertex(v), head(nullptr) {}
};

void addEdge(Edge *graph, int src, int dest, int weight)
{
    EdgeNode *newNode = new EdgeNode(dest, weight);
    newNode->next = graph[src].head;
    graph[src].head = newNode;
}

void createGraph(Edge *graph, int V)
{
    for (int i = 0; i < V; i++)
    {
        graph[i] = Edge(i);
    }

    int numEdges;
    cout << "Enter the number of edges: ";
    cin >> numEdges;

    for (int i = 0; i < numEdges; ++i)
    {
        int src, dest, weight, edgeID;
        cout << "Enter source, destination, and weight for edge " << i + 1 << ": ";
        cin >> src >> dest >> weight;

        if (src >= V || dest >= V)
        {
            cout << "Invalid vertex ID. Edge not added." << endl;
            continue;
        }

        addEdge(graph, src, dest, weight);
    }
}

void displayGraph(Edge *graph, int V)
{
    cout << "Adjacency List Representation:" << endl;
    for (int i = 1; i <= V; i++)
    {
        cout << "Vertex " << i << " --> ";
        EdgeNode *curr = graph[i].head;
        while (curr != nullptr)
        {
            cout << "(" << curr->dest << ", " << curr->weight << ") ";
            curr = curr->next;
        }
        cout << endl;
    }
}

struct Pair
{
    int node;
    int distance;
    Pair(int n, int d) : node(n), distance(d) {}
    bool operator<(const Pair &p2) const
    {
        return distance > p2.distance;
    }
};

void dijkstra(Edge *graph, int source, int V, int distance[])
{
    priority_queue<Pair> priorqueue;

    bool *visited = new bool[V];
    for (int i = 0; i < V; i++)
    {
        visited[i] = false;
    }

    for (int i = 0; i < V; i++)
    {
        distance[i] = INT_MAX;
    }
    distance[source] = 0;
    priorqueue.push(Pair(source, 0));

    while (!priorqueue.empty())
    {
        Pair curr = priorqueue.top();
        priorqueue.pop();

        if (!visited[curr.node])
        {
            visited[curr.node] = true;
            EdgeNode *edge = graph[curr.node].head;

            while (edge != nullptr)
            {
                int u = curr.node;
                int v = edge->dest;
                if (distance[u] != INT_MAX && distance[u] + edge->weight < distance[v])
                {
                    distance[v] = distance[u] + edge->weight;
                    priorqueue.push(Pair(v, distance[v]));
                }
                edge = edge->next;
            }
        }
    }
}

int main()
{
    int V; // Number of vertices
    cout << "Enter the number of vertices: ";
    cin >> V;

    Edge *graph = new Edge[V];

    int choice;
    do
    {
        cout << "\nMenu:\n"
                "1. Create Graph\n"
                "2. Display Graph (Adjacency List Representation)\n"
                "3. Find Shortest Paths using Dijkstra's Algorithm\n"
                "5. Exit\n"
                "Enter your choice: ";
        cin >> choice;

        switch (choice)
        {
        case 1:
            createGraph(graph, V);
            break;

        case 2:
            displayGraph(graph, V);
            break;

        case 3:
        {
            int source;
            cout << "Enter the source vertex: ";
            cin >> source;

            int *distance = new int[V];
            dijkstra(graph, source, V, distance);

            cout << "Shortest distances from vertex " << source << " to other vertices:\n";
            for (int i = 0; i < V; ++i)
            {
                cout << "Vertex " << i << ": ";
                if (distance[i] == INT_MAX)
                {
                    cout << "INF\n";
                }
                else
                {
                    cout << distance[i] << '\n';
                }
            }
            delete[] distance;
            break;
        }

        case 5:
            cout << "Exiting...\n";
            break;

        default:
            cout << "Invalid choice! Please enter a valid option.\n";
        }
    } while (true);

    delete[] graph;

    return 0;
}