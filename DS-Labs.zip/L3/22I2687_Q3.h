#include <iostream>
using namespace std;

char **words_to_sentence(int rows, int cols)
{
    int row = 5, col = 5;
    char *word = nullptr;
    char **sentence = new char *[row];
    cout << "\nEnter the following words one by one [\"hello\",\"world\",\"how\",\"are\",\"you\" ] (Always press enter after entering one word): " << endl;
    for (int i = 0; i < row; i++)
    {
        word = new char[col];
        if (i >= 2)
        {
            col = 3;
        }
        for (int j = 0; j < col; j++)
        {
            cin >> word[j];
        }
        sentence[i] = word;
    }
    return sentence;
}