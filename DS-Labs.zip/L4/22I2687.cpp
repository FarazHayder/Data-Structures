#include "22I2687_Q1.h"
#include "22I2687_Q2.h"
#include "22I2687_Q3.h"

int main()
{
    // Q1
    cout << "Enter number of rows for your Matrix: ";
    int rows1 = 0;
    cin >> rows1;
    cout << "Enter number of columns for your Matrix: ";
    int columns1 = 0;
    cin >> columns1;
    // Making a 2d array with dimensions 3x3
    int **arr1 = new int *[rows1];
    for (int i = 0; i < rows1; i++)
    {
        arr1[i] = new int[columns1];
    }
    // Taking values in array as input
    cout << "Enter values for your array: " << endl;
    for (int i = 0; i < rows1; i++)
    {
        for (int j = 0; j < columns1; j++)
        {
            cin >> arr1[i][j];
        }
    }
    sortingAlgo array;
    array.setArr(arr1, rows1, columns1);
    array.sort();
    array.print();

    for (int i = 0; i < rows1; i++)
    {
        delete[] arr1[i];
    }
    delete[] arr1;

    // Q2
    // cout << "Enter number of rows for your Matrix: ";
    // int rows2 = 0;
    // cin >> rows2;
    // cout << "Enter number of columns for your Matrix: ";
    // int columns2 = 0;
    // cin >> columns2;
    // // Making a 2d array with dimensions 3x3
    // char **arr2 = new char *[rows2];
    // for (int i = 0; i < rows2; i++)
    // {
    //     arr2[i] = new char[columns2];
    // }
    // // Taking values in array as input
    // cout << "Enter values for your array: " << endl;
    // for (int i = 0; i < rows2; i++)
    // {
    //     for (int j = 0; j < columns2; j++)
    //     {
    //         cin >> arr2[i][j];
    //     }
    // }
    // cout << "Now enter the word you want to search in the array: ";
    // char *word = new char[3];
    // cin >> word;
    // // Creating array to store indices
    // int **indices = new int *[2];
    // for (int i = 0; i < 2; i++)
    // {
    //     indices[i] = new int[3];
    // }
    // indices = Find(arr2, rows2, columns2, word);
    // // Function to print the array
    // for (int i = 0; i < 3; i++)
    // {
    //     for (int j = 0; j < 3; j++)
    //     {
    //         cout << indices[i][j] << " ";
    //     }
    //     cout << endl;
    // }
    // for (int i = 0; i < rows2; i++)
    // {
    //     delete[] arr2[i];
    // }
    // delete[] arr2;
    // for (int i = 0; i < 2; i++)
    // {
    //     delete[] indices[i];
    // }
    // delete[] indices;
    // delete[] word;

    // Q3
    // cout << "Enter number of rows for your Matrix: ";
    // int rows3 = 0;
    // cin >> rows3;
    // cout << "Enter number of columns for your Matrix: ";
    // int columns3 = 0;
    // cin >> columns3;
    // // Making a 2d array with dimensions 3x3
    // float **arr3 = new float *[rows3];
    // for (int i = 0; i < rows3; i++)
    // {
    //     arr3[i] = new float[columns3];
    // }
    // // Taking values in array as input
    // cout << "Enter values for your array: " << endl;
    // for (int i = 0; i < rows3; i++)
    // {
    //     for (int j = 0; j < columns3; j++)
    //     {
    //         cin >> arr3[i][j];
    //     }
    // }

    // bool checkMarkovMatrix = false;
    // checkMarkovMatrix = MarkovMatrix(arr3, rows3, columns3);
    // if (checkMarkovMatrix == false)
    // {
    //     cout << "The array is not a Markov Matrix." << endl;
    // }
    // else if (checkMarkovMatrix == true)
    // {
    //     cout << "The array is a Markov Matrix." << endl;
    // }
    // for (int i = 0; i < rows3; i++)
    // {
    //     delete[] arr3[i];
    // }
    // delete[] arr3;

    return 0;
}