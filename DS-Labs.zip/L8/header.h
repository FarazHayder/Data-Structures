#include <iostream>
#include <conio.h>
using namespace std;

void Q1();
// void Q2();
void Q3();
// void Q4();

void MainMenu()
{
    // For clearing console screen
    system("cls");
    char option;
    cout << "\n<===================== Main Menu =====================>" << endl
         << "\nPress '1' to continue to 'Q1'" << endl
         << "Press '2' to continue to 'Q2'" << endl
         << "Press '3' to continue to 'Q3'" << endl
         << "Press '4' to continue to 'Q4'" << endl
         << "Press '5' to 'Exit'" << endl;
    option = getch();

    while (!(option == '1' || option == '2' || option == '3' || option == '4' || option == '5'))
    {
        option = getch();
    }

    switch (option)
    {
    case '1':
        // For clearing console screen
        system("cls");
        Q1();
        break;

    case '2':
        // For clearing console screen
        system("cls");
        // Q2();
        break;

    case '3':
        // For clearing console screen
        system("cls");
        Q3();
        break;

    case '4':
        // For clearing console screen
        system("cls");
        // Q4();
        break;

    case '5':
        // For clearing console screen
        system("cls");
        exit(0);
        break;
    }
    MainMenu();
}
// Provides a link to the Main Menu
void MainMenuLink()
{
    char ch;
    cout << "\nPress 'Esc' to 'Go Back' or press 'Enter' to continue to 'Main Menu'" << endl;
    ch = getch();
    while (ch != '\x1B' && ch != '\r')
    {
        ch = getch();
    }
    if (ch == '\r')
    {
        // For clearing console screen
        system("cls");
        MainMenu();
    }
    // For clearing console screen
    system("cls");
}

struct Node
{
    int id;
    string name;
    Node *next;
};
class Queue
{
    Node *front;
    Node *rear;
    int numItems;

public:
    Queue();
    ~Queue();
    int size();
    bool isEmpty();
    void makeNull();
    void enqueue(int, string);
    void dequeue();
    void display();
    Node *showFront();
    Node *showRear();
    void getRear();
};
Queue::Queue()
{
    front = NULL;
    rear = NULL;
    numItems = 0;
}
Queue::~Queue()
{
    makeNull();
}
int Queue::size()
{
    return numItems;
}
bool Queue::isEmpty()
{
    return (numItems == 0);
}
void Queue::makeNull()
{
    while (!isEmpty())
    {
        dequeue();
    }
}
void Queue::enqueue(int id, string name)
{
    Node *newNode = new Node;
    newNode->id = id;
    newNode->name = name;
    newNode->next = NULL;
    if (isEmpty())
    {
        front = newNode;
        rear = newNode;
    }
    else
    {
        rear->next = newNode;
        rear = newNode;
    }
    numItems++;
}
void Queue::dequeue()
{
    if (isEmpty())
    {
        cout << "Queue is empty" << endl;
    }
    else
    {
        Node *temp = front;
        front = front->next;
        delete temp;
        numItems--;
    }
}
void Queue::display()
{
    if (isEmpty())
    {
        cout << "Queue is empty" << endl;
    }
    else
    {
        Node *temp = front;
        while (temp != NULL)
        {
            cout << temp->id << " " << temp->name << endl;
            temp = temp->next;
        }
    }
}
Node *Queue::showFront()
{
    if (isEmpty())
    {
        cout << "Queue is empty" << endl;
    }
    else
    {
        return front;
    }
}
Node *Queue::showRear()
{
    if (isEmpty())
    {
        cout << "Queue is empty" << endl;
    }
    else
    {
        return rear;
    }
}

void Q1()
{
    //  Createing queue
    Queue queue;
    queue.enqueue(1, "Ali");
    queue.enqueue(2, "Bilal");
    queue.enqueue(3, "Chaudhary");
    queue.display(); // Displaying queue
    cout << endl;

    // Checking if queue is empty
    if (!queue.isEmpty())
    {
        cout << "Queue is not empty" << endl
             << endl;
    }
    else
    {
        cout << "Queue is empty" << endl
             << endl;
    }

    // Showing front of queue
    cout << "Front: " << queue.showFront()->id << endl;
    cout << "Front: " << queue.showFront()->name << endl
         << endl;

    // Dequeueing
    queue.dequeue();
    queue.display();

    MainMenuLink();
}

void Q3()
{
    //  Createing queue
    Queue queue1;
    queue1.enqueue(1, "Ali");
    queue1.enqueue(2, "Bilal");
    queue1.enqueue(3, "Chaudhary");
    queue1.enqueue(4, "Dilawar");
    queue1.enqueue(5, "Ehsan");
    queue1.display(); // Displaying queue

    //  Createing queue
    Queue queue2;
    Queue queue3;
    int size = queue1.size();
    for (int n = 0; n < size; n++)
    {
        if (n % 2 == 0)
        {
            int queue1Size = queue1.size();
            for (int i = 0; i < queue1Size; i++)
            {
                if (i == queue1Size - 1)
                {
                    queue3.enqueue(queue1.showFront()->id, queue1.showFront()->name);
                    queue1.dequeue();
                }
                else
                {
                    queue2.enqueue(queue1.showFront()->id, queue1.showFront()->name);
                    queue1.dequeue();
                }
            }
        }
        else
        {
            int queue2Size = queue2.size();
            for (int i = 0; i < queue2Size; i++)
            {
                if (i == queue2Size - 1)
                {
                    queue3.enqueue(queue2.showFront()->id, queue2.showFront()->name);
                    queue2.dequeue();
                }
                else
                {
                    queue1.enqueue(queue2.showFront()->id, queue2.showFront()->name);
                    queue2.dequeue();
                }
            }
        }
    }
    cout << endl;
    queue3.display(); // Displaying queue

    MainMenuLink();
}