#include "I222687.h"

int main()
{

    LinkedList l1;
    cout << l1.isEmpty() << endl;
    Employee E1(1, "123", 1000, 100);
    Employee E2(2, "456", 2000, 200);
    Employee E3(3, "789", 3000, 300);
    l1.Insert(E1);
    // cout << "TESTING" << endl;
    l1.Insert(E2);
    l1.Insert(E3);
    l1.display();
    l1.remove(2);
    l1.display();
    l1.UpdateSalary(200, 1);
    l1.UpdateBonus(150, 1);
    l1.display();
    cout << l1.isEmpty() << endl;
    cout << endl;
    l1.sort();
    l1.display();

    return 0;
}