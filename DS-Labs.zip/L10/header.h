// gatesmashers
// cppNuts
#include <iostream>
#include <conio.h>
using namespace std;

struct TreeNode
{
    int value;
    TreeNode *left;
    TreeNode *right;
};
class IntBinaryTree
{
private:
    TreeNode *root; // Pointer to the root of BST
    // void destroySubTree(TreeNode *); // Recursively delete all tree nodes
    void deleteNode(int, TreeNode *&);
    void makeDeletion(TreeNode *&);
    // void displayInOrder(TreeNode *);
    // void displayPreOrder(TreeNode *);
    // void displayPostOrder(TreeNode *);
    int heightOfBST(TreeNode *root);
    void depthOfNodeInBST();
    int numberOfNodesInRangeInBST(TreeNode *root, int l, int r);
    void smallestElementInBST();

public:
    void MainMenu();
    void MainMenuLink();
    IntBinaryTree() { root = NULL; }
    // ~IntBinaryTree() { destroySubTree(root); }
    void insertNode(int);
    bool find(int);
    void remove(int num) { deleteNode(num, root); }
    // void showNodesInOrder() { displayInOrder(root); }
    // void showNodesPreOrder() { displayPreOrder(root); }
    // void showNodesPostOrder() { displayPostOrder(root); }
    void displayHeightOfBST();
    int displayNumberOfNodesInRangeInBST();
    void smallervalues(TreeNode *root, int &count)
    {
        if (!root)
        {
            return;
        }

        else
        {
            smallervalues(root->left, count);
            count++;
            smallervalues(root->left, count);
        }
    }
    void find(TreeNode *&currNode, int x)
    {
        while (!currNode)
        {
            if (currNode->value == x)
            {
                return;
            }
            else if (currNode->value > x)
            {
                currNode = currNode->left;
            }
            else if (currNode->value < x)
            {
                currNode = currNode->right;
            }
        }
    }
    int totalSmallerValues(int x)
    {
        TreeNode *currNode = root;
        find(currNode, x);
        int count = -1;
        smallervalues(currNode, count);
        return count;
    }
};

void IntBinaryTree::MainMenu()
{
    // For clearing console screen
    system("cls");
    char option;
    cout << "\n<===================== Main Menu =====================>" << endl
         << "\nPress '1' to find 'Height of BST'" << endl
         << "Press '2' to find 'Depth of a node in BST'" << endl
         << "Press '3' to 'Count Nodes in a range'" << endl
         << "Press '4' to find 'kth smallest number of BST'" << endl
         << "Press '5' to 'Exit'" << endl;
    option = getch();

    while (!(option == '1' || option == '2' || option == '3' || option == '4' || option == '5'))
    {
        option = getch();
    }

    switch (option)
    {
    case '1':
        // For clearing console screen
        system("cls");
        displayHeightOfBST();
        break;

    case '2':
        // For clearing console screen
        system("cls");
        depthOfNodeInBST();
        break;

    case '3':
        // For clearing console screen
        system("cls");
        displayNumberOfNodesInRangeInBST();
        break;

    case '4':
        // For clearing console screen
        system("cls");
        smallestElementInBST();
        break;

    case '5':
        // For clearing console screen
        system("cls");
        exit(0);
        break;
    }
    MainMenu();
}
// Provides a link to the Main Menu
void IntBinaryTree::MainMenuLink()
{
    char ch;
    cout << "\nPress any key to continue..." << endl;
    ch = getch();
    // For clearing console screen
    system("cls");
}

bool IntBinaryTree::find(int num)
{
    // The function starts from the root
    TreeNode *nodePtr = root;
    while (nodePtr)
    {
        if (nodePtr->value == num)
            return true; // value is found
        else if (num < nodePtr->value)
            nodePtr = nodePtr->left;
        else
            nodePtr = nodePtr->right;
    }
    return false; // value not found
}
void IntBinaryTree::insertNode(int num)
{
    TreeNode *newNode, *nodePtr; // Pointer to create new node & traverse tree
    newNode = new TreeNode;      // Create a new node
    newNode->value = num;
    newNode->left = newNode->right = NULL;
    if (!root)
        root = newNode; // If tree is empty.
    else
    { // Tree is not empty
        nodePtr = root;
        while (nodePtr != NULL)
        {
            if (num < nodePtr->value)
            { // Left subtree
                if (nodePtr->left)
                {
                    nodePtr = nodePtr->left;
                }
                else
                {
                    nodePtr->left = newNode;
                    break;
                }
            }
            else if (num > nodePtr->value)
            { // Right subtree
                if (nodePtr->right)
                    nodePtr = nodePtr->right;
                else
                {
                    nodePtr->right = newNode;
                    break;
                }
            }
            else
            {
                cout << "Duplicate value found in tree.\n";
                break;
            }
        }
    }
}
void IntBinaryTree::deleteNode(int num, TreeNode *&nodePtr)
{
    bool check = find(num);
    if (!check) // node does not exist in the tree
        cout << num << " not found.\n";
    else                       // num == nodePtr->value i.e. node is found
        makeDeletion(nodePtr); // actually deletes node from BST
}
void IntBinaryTree::makeDeletion(TreeNode *&nodePtr)
{
    TreeNode *tempNodePtr; // Temperary pointer
    if (nodePtr->right == NULL)
    { // case for leaf and one (left) child
        tempNodePtr = nodePtr;
        nodePtr = nodePtr->left; // Reattach the left child
        delete tempNodePtr;
    }
    else if (nodePtr->left == NULL)
    { // case for one (right) child
        tempNodePtr = nodePtr;
        nodePtr = nodePtr->right; // Reattach the right child
        delete tempNodePtr;
    }
    else
    {                                 // case for two children.
        tempNodePtr = nodePtr->right; // Move one node to the right
        while (tempNodePtr->left)
        { // Go to the extreme left node
            tempNodePtr = tempNodePtr->left;
        }
        tempNodePtr->left = nodePtr->left; // Reattach the left subtree
        tempNodePtr = nodePtr;
        nodePtr = nodePtr->right; // Reattach the right subtree
        delete tempNodePtr;
    }
}

int IntBinaryTree::heightOfBST(TreeNode *root)
{
    if (root == NULL)
    {
        return 0;
    }
    int leftHeight = heightOfBST(root->left);
    int rightHeight = heightOfBST(root->right);
    return max(leftHeight, rightHeight) + 1;
}
void IntBinaryTree::displayHeightOfBST()
{
    cout << "Height of BST is: " << heightOfBST(root) - 1;
    MainMenuLink();
}
void IntBinaryTree::depthOfNodeInBST()
{
    // Now finding depth of a node in BST
    int num;
    cout << "Enter the node value to find its depth: ";
    cin >> num;
    int depth = 0;
    bool check = false;
    TreeNode *nodePtr = root;
    while (nodePtr)
    {
        if (nodePtr->value == num)
        {
            cout << "Depth of " << num << " is: " << depth << endl;
            check = true;
            break;
        }
        else if (num < nodePtr->value)
        {
            nodePtr = nodePtr->left;
            depth++;
        }
        else if (num > nodePtr->value)
        {
            nodePtr = nodePtr->right;
            depth++;
        }
    }
    if (!check) // node does not exist in the tree
    {
        cout << num << " not found.\n";
    }
    MainMenuLink();
}
int IntBinaryTree::numberOfNodesInRangeInBST(TreeNode *root, int l, int r)
{
    if (root == nullptr)
    {
        return 0;
    }
    if (root->value >= l && root->value <= r)
    {
        return 1 + numberOfNodesInRangeInBST(root->left, l, r) + numberOfNodesInRangeInBST(root->right, l, r);
    }
    else if (root->value < l)
    {
        return numberOfNodesInRangeInBST(root->right, l, r);
    }
    else
    {
        return numberOfNodesInRangeInBST(root->left, l, r);
    }
}
int IntBinaryTree::displayNumberOfNodesInRangeInBST()
{
    int l, r;
    cout << "Enter the range: ";
    cin >> l >> r;
    cout << "Height of BST is: " << numberOfNodesInRangeInBST(root, l, r);
    MainMenuLink();
}
void IntBinaryTree::smallestElementInBST()
{
    // Now finding smallest element in BST
    TreeNode *nodePtr = root;
    while (nodePtr->left)
    {
        nodePtr = nodePtr->left;
    }
    cout << "Smallest element in BST is: " << nodePtr->value << endl;

    MainMenuLink();
}