#include <iostream>
#include <stack>
#include <iomanip>
#include <conio.h>

using namespace std;

int INT_MAX = 2147483647;

// Forward declarations
struct Edge;
struct Node;

// Edge structure
struct Edge
{
    Node *destination;
    int length;
    Edge *next;

    Edge(Node *dest, int len)
    {
        destination = dest;
        length = len;
        next = nullptr;
    }
};

// Node structure
struct Node
{
    int id;
    Node *next;
    Edge *edges;

    Node(int intersectionID)
    {
        id = intersectionID;
        next = nullptr;
        edges = nullptr;
    }
};

// CityMap class
class CityMap
{
private:
    Node *head;

public:
    CityMap()
    {
        head = nullptr;
    }

    // Function to add an intersection to the city map
    void addIntersection(int intersectionID)
    {
        Node *newNode = new Node(intersectionID);
        newNode->next = head;
        head = newNode;
    }

    // Function to add a road between two intersections with a specified length
    void addRoad(int source, int destination, int length)
    {
        Node *sourceNode = nullptr;
        Node *destNode = nullptr;

        // Find the source and destination nodes
        Node *current = head;
        while (current != nullptr && (!sourceNode || !destNode))
        {
            if (current->id == source)
                sourceNode = current;
            if (current->id == destination)
                destNode = current;
            current = current->next;
        }

        if (sourceNode && destNode)
        {
            Edge *newEdge = new Edge(destNode, length);
            newEdge->next = sourceNode->edges;
            sourceNode->edges = newEdge;

            // Since the graph is undirected, add an edge in the opposite direction as well
            newEdge = new Edge(sourceNode, length);
            newEdge->next = destNode->edges;
            destNode->edges = newEdge;
        }
    }

    // Function to display the city map
    void displayCityMap()
    {
        Node *current = head;
        while (current != nullptr)
        {
            cout << "Intersection " << current->id << " -> ";
            Edge *edge = current->edges;
            while (edge != nullptr)
            {
                cout << "Intersection " << edge->destination->id << " (Length: " << edge->length << ") ";
                edge = edge->next;
            }
            cout << endl;
            current = current->next;
        }
    }

    // Function to find the shortest path between two intersections using Dijkstra's algorithm
    void findShortestPath(int start, int end)
    {
        // Create arrays to store distances and previous nodes
        int *distance = new int[head->id + 1];
        int *previous = new int[head->id + 1];
        bool *visited = new bool[head->id + 1];

        // Initialize distances, previous nodes, and visited array
        for (int i = 1; i <= head->id; i++)
        {
            int INT_MAX = 100;
            distance[i] = INT_MAX;
            previous[i] = -1;
            visited[i] = false;
        }

        // Find the start and end nodes
        Node *startNode = nullptr;
        Node *endNode = nullptr;

        Node *current = head;
        while (current != nullptr)
        {
            if (current->id == start)
            {
                startNode = current;
            }
            if (current->id == end)
            {
                endNode = current;
            }
            current = current->next;
        }

        if (!startNode || !endNode)
        {
            cout << "Start or end intersection not found." << endl;
            delete[] distance;
            delete[] previous;
            delete[] visited;
            return;
        }

        // Set the distance of the start node to 0
        distance[start] = 0;

        // Dijkstra's algorithm
        for (int i = 1; i <= head->id; i++)
        {
            int INT_MAX = 100;
            int minDistance = INT_MAX;
            int u = -1;

            // Find the intersection with the smallest distance among unvisited intersections
            for (int j = 1; j <= head->id; j++)
            {
                if (!visited[j] && distance[j] < minDistance)
                {
                    minDistance = distance[j];
                    u = j;
                }
            }

            if (u == -1)
            {
                break; // No more reachable intersections
            }

            visited[u] = true;

            // Update the distance of adjacent intersections
            current = head;
            while (current != nullptr)
            {
                Edge *edge = current->edges;
                while (edge != nullptr)
                {
                    int v = edge->destination->id;
                    if (!visited[v] && distance[u] != INT_MAX &&
                        distance[u] + edge->length < distance[v])
                    {
                        distance[v] = distance[u] + edge->length;
                        previous[v] = u;
                    }
                    edge = edge->next;
                }
                current = current->next;
            }
        }

        // Reconstruct and print the shortest path
        int currentIntersection = end;
        stack<int> path;

        while (currentIntersection != -1)
        {
            path.push(currentIntersection);
            currentIntersection = previous[currentIntersection];
        }

        if (path.top() != start)
        {
            cout << "No path exists between Intersection " << start << " and Intersection " << end << "." << endl;
        }
        else
        {
            cout << "Shortest Path from Intersection " << start << " to Intersection " << end << ": ";
            while (!path.empty())
            {
                cout << "Intersection " << path.top();
                path.pop();
                if (!path.empty())
                {
                    cout << " -> ";
                }
            }
            cout << " (Total Length: " << distance[end] << ")" << endl;
        }

        // Clean up dynamic arrays
        delete[] distance;
        delete[] previous;
        delete[] visited;
    }
};

void printMenu()
{
    // For clearing console screen
    system("cls");
    cout << "<===== City Map Menu =====>" << endl
         << endl;
    cout << "1. Add Intersection" << endl;
    cout << "2. Add Road" << endl;
    cout << "3. Display City Map" << endl;
    cout << "4. Find Shortest Path" << endl;
    cout << "5. Exit" << endl;
    cout << "==========================" << endl
         << endl;
    cout << "Enter your choice: ";
}

void Continue()
{
    cout << "Press any key to continue..." << endl;
    getch();
}
int main()
{
    CityMap cityMap;

    int choice;
    do
    {
        printMenu();
        cin >> choice;

        switch (choice)
        {
        case 1:
        {
            int intersectionID;
            cout << "Enter Intersection ID: ";
            cin >> intersectionID;
            cityMap.addIntersection(intersectionID);
            Continue();
            break;
        }
        case 2:
        {
            int source, destination, length;
            cout << "Enter Source Intersection ID: ";
            cin >> source;
            cout << "Enter Destination Intersection ID: ";
            cin >> destination;
            cout << "Enter Length: ";
            cin >> length;
            cityMap.addRoad(source, destination, length);
            Continue();
            break;
        }
        case 3:
            cityMap.displayCityMap();
            Continue();
            break;
        case 4:
        {
            int start, end;
            cout << "Enter Start Intersection ID: ";
            cin >> start;
            cout << "Enter End Intersection ID: ";
            cin >> end;
            cityMap.findShortestPath(start, end);
            Continue();
            break;
        }
        case 5:
            cout << "Exiting... Thank you!" << endl;
            break;
        default:
            cout << "Invalid choice. Please enter a valid option." << endl;
        }
    } while (choice != 5);

    return 0;
}