#include <iostream>
using namespace std;
#include <string.h>
#include <string>

void Find(string text, char charToSearch)
{
    int size = 0;
    int temp = 0;
    int count = 0;
    while (text[temp] != '\0')
    {
        size++;
        temp++;
    }
    for (int i = 0; i < size; i++)
    {
        if (text[i] == charToSearch)
        {
            temp = i;
            break;
        }
        count++;
    }
    for (int i = temp; i < size; i++)
    {
        cout << text[i];
    }
    if (count == size)
    {
        cout << "The character you entered is not in the string!" << endl;
    }
}