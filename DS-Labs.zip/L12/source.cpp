#include "header.h"

int main()
{
    avlTree.DisplayMenu(avlTree);

    return 0;
}
