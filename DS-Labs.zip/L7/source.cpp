#include "header.h"

int main()
{
    Stack<Student> studentStack;
    loadCSVData("file1.csv", studentStack);

    MyVector<Student> stdData;
    transferStackToVector(studentStack, stdData);
    int choice;
    do
    {
        // For clearing console screen
        system("cls");
        cout << "\n<========= Main Menu =========>\n"
             << endl;
        cout << "1. Display student data\n";
        cout << "2. Sort by Roll No\n";
        cout << "3. Sort by Name\n";
        cout << "4. Sort by Assignment 1\n";
        cout << "5. Sort by Assignment 2\n";
        cout << "6. Sort by Assignment 3\n";
        cout << "7. Sort by Assignment 4\n";
        cout << "8. Sort by Assignments\n";
        cout << "9. Sort by Sessional 1\n";
        cout << "10. Sort by Sessional 2\n";
        cout << "11. Sort by Project 1\n";
        cout << "12. Sort by Project 2\n";
        cout << "13. Sort by Final 1\n";
        cout << "14. Sort by Final 2\n";
        cout << "15. Sort by Mids 1\n";
        cout << "16. Sort by Mids 2\n";
        cout << "17. Sort by Grand Total\n";
        cout << "18. Sort by Grades\n";
        cout << "19. Exit\n"
             << endl;
        cout << "Enter your choice: ";
        cin >> choice;
        Stack<Student> StudentStack;
        switch (choice)
        {
        case 1:
            displayStudentData(stdData);
            break;
        case 2:
            sortByR_N(stdData);
            system("cls");
            cout << "Data Sorted and Saved to File \"SortedBy_RollNumber\" Successfully!\n";
            transferVectorToStack(stdData, StudentStack);
            saveStackToCSV("SortedBy_RollNumber.csv", StudentStack);
            Continue();
            break;
        case 3:
            sortByName(stdData);
            system("cls");
            cout << "Data Sorted and Saved to File \"SortedBy_Name\" Successfully!\n";
            transferVectorToStack(stdData, StudentStack);
            saveStackToCSV("SortedBy_Name.csv", StudentStack);
            Continue();
            break;
        case 4:
            sortByA1(stdData);
            system("cls");
            cout << "Data Sorted and Saved to File \"SortedBy_Assignment1\" Successfully!\n";
            transferVectorToStack(stdData, StudentStack);
            saveStackToCSV("SortedBy_Assignment1.csv", StudentStack);
            Continue();
            break;
        case 5:
            sortByA2(stdData);
            system("cls");
            cout << "Data Sorted and Saved to File \"SortedBy_Assignment2\" Successfully!\n";
            transferVectorToStack(stdData, StudentStack);
            saveStackToCSV("SortedBy_Assignment2.csv", StudentStack);
            Continue();
            break;
        case 6:
            sortByA3(stdData);
            system("cls");
            cout << "Data Sorted and Saved to File \"SortedBy_Assignment3\" Successfully!\n";
            transferVectorToStack(stdData, StudentStack);
            saveStackToCSV("SortedBy_Assignment3.csv", StudentStack);
            Continue();
            break;
        case 7:
            sortByA4(stdData);
            system("cls");
            cout << "Data Sorted and Saved to File \"SortedBy_Assignment4\" Successfully!\n";
            transferVectorToStack(stdData, StudentStack);
            saveStackToCSV("SortedBy_Assignment4.csv", StudentStack);
            Continue();
            break;
        case 8:
            sortByAs(stdData);
            system("cls");
            cout << "Data Sorted and Saved to File \"SortedBy_Assignments\" Successfully!\n";
            transferVectorToStack(stdData, StudentStack);
            saveStackToCSV("SortedBy_Assignments.csv", StudentStack);
            Continue();
            break;
        case 9:
            sortByS1(stdData);
            system("cls");
            cout << "Data Sorted and Saved to File \"SortedBy_Sessionals1\" Successfully!\n";
            transferVectorToStack(stdData, StudentStack);
            saveStackToCSV("SortedBy_Sessionals1.csv", StudentStack);
            Continue();
            break;
        case 10:
            sortByS2(stdData);
            system("cls");
            cout << "Data Sorted and Saved to File \"SortedBy_Sessionals2\" Successfully!\n";
            transferVectorToStack(stdData, StudentStack);
            saveStackToCSV("SortedBy_Sessionals2.csv", StudentStack);
            Continue();
            break;
        case 11:
            sortByP1(stdData);
            system("cls");
            cout << "Data Sorted and Saved to File \"SortedBy_Project1\" Successfully!\n";
            transferVectorToStack(stdData, StudentStack);
            saveStackToCSV("SortedBy_Project1.csv", StudentStack);
            Continue();
            break;
        case 12:
            sortByP2(stdData);
            system("cls");
            cout << "Data Sorted and Saved to File \"SortedBy_Project2\" Successfully!\n";
            transferVectorToStack(stdData, StudentStack);
            saveStackToCSV("SortedBy_Project2.csv", StudentStack);
            Continue();
            break;
        case 13:
            sortByF1(stdData);
            system("cls");
            cout << "Data Sorted and Saved to File \"SortedBy_Finals1\" Successfully!\n";
            transferVectorToStack(stdData, StudentStack);
            saveStackToCSV("SortedBy_Finals1.csv", StudentStack);
            Continue();
            break;
        case 14:
            sortByF2(stdData);
            system("cls");
            cout << "Data Sorted and Saved to File \"SortedBy_Finals2\" Successfully!\n";
            transferVectorToStack(stdData, StudentStack);
            saveStackToCSV("SortedBy_Finals2.csv", StudentStack);
            Continue();
            break;
        case 15:
            sortBymid1(stdData);
            system("cls");
            cout << "Data Sorted and Saved to File \"SortedBy_Mids1\" Successfully!\n";
            transferVectorToStack(stdData, StudentStack);
            saveStackToCSV("SortedBy_Mids1.csv", StudentStack);
            Continue();
            break;
        case 16:
            sortBymid2(stdData);
            system("cls");
            cout << "Data Sorted and Saved to File \"SortedBy_Mids2\" Successfully!\n";
            transferVectorToStack(stdData, StudentStack);
            saveStackToCSV("SortedBy_Mids2.csv", StudentStack);
            Continue();
            break;
        case 17:
            sortBygtot(stdData);
            system("cls");
            cout << "Data Sorted and Saved to File \"SortedBy_GrandTotal\" Successfully!\n";
            transferVectorToStack(stdData, StudentStack);
            saveStackToCSV("SortedBy_GrandTotal.csv", StudentStack);
            Continue();
            break;
        case 18:
            sortBygrade(stdData);
            system("cls");
            cout << "Data Sorted and Saved to File \"SortedBy_Grades\" Successfully!\n";
            transferVectorToStack(stdData, StudentStack);
            saveStackToCSV("SortedBy_Grades.csv", StudentStack);
            Continue();
            break;
        case 19:
            return 0;
        default:
            cout << "Invalid choice. Try again.\n";
            break;
        }
    } while (choice != 19);

    return 0;
}