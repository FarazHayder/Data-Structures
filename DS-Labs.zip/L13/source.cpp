#include <iostream>
#include <vector>
using namespace std;

struct weightedEdge
{
    int vertex;
    int weight;
};

struct neighbor
{
    int vertex;
    vector<weightedEdge> edges;
};

class Graph
{
    int numOfVertices;
    vector<neighbor> adjList;

public:
    Graph(int numOfVertices)
    {
        this->numOfVertices = numOfVertices;
        adjList.resize(numOfVertices);
    }
    void addVertices(int vertex, vector<weightedEdge> edges)
    {
        numOfVertices++;
        adjList.resize(numOfVertices);
        adjList[numOfVertices - 1].vertex = vertex;
        adjList[numOfVertices - 1].edges = edges;
        // Now making it undirected
        for (int i = 0; i < edges.size(); i++)
        {
            for (int j = 0; j < adjList.size(); j++)
            {
                if (adjList[j].vertex == edges[i].vertex)
                {
                    // Check if the vertex is already present in the list
                    bool duplicate = false;
                    for (int k = 0; k < adjList[j].edges.size(); k++)
                    {
                        if (adjList[j].edges[k].vertex == vertex)
                        {
                            duplicate = true;
                        }
                    }
                    if (!duplicate)
                    {
                        adjList[j].edges.push_back(edges[j]);
                        break;
                    }
                }
            }
        }
    }
    void printGraph()
    {
        for (int i = 0; i < adjList.size(); i++)
        {
            cout << adjList[i].vertex << " : ";
            for (int j = 0; j < adjList[i].edges.size(); j++)
            {
                cout << "(" << adjList[i].edges[j].vertex << ", " << adjList[i].edges[j].weight << ")"
                     << " ";
            }
            cout << endl;
        }
    }
};

int main()
{

    Graph graph(0);

    graph.addVertices(4, {{0, 1}, {1, 1}});
    graph.addVertices(3, {{4, 1}, {2, 1}});
    graph.addVertices(2, {{1, 1}, {3, 1}});
    graph.addVertices(1, {{2, 1}, {3, 1}});
    graph.addVertices(0, {{1, 1}, {4, 1}});
    graph.printGraph();

    return 0;
}