#include "22I2687_Q1.h"
#include "22I2687_Q2.h"
#include "22I2687_Q3.h"
#include "22I2687_Q4.h"

int main()
{
    // Q1
    // {
    //     cout << "Enter size of the array: ";
    //     int size = 0;
    //     cin >> size;
    //     while (size < 10)
    //     {
    //         cout << "Size must be greater than 10." << endl;
    //         cout << "\nEnter size of the array: ";
    //         cin >> size;
    //     }

    //     int *array = new int[size];
    //     cout << "Enter values of array:\n";
    //     for (int i = 0; i < size; i++)
    //     {
    //         cin >> array[i];
    //     }

    //     int minimum = 0, maximum = 0;
    //     minimum = min(array, size);
    //     cout << "\nMinimum = " << minimum << endl;
    //     ;
    //     maximum = max(array, size);
    //     cout << "Maximum = " << maximum << endl;
    //     ;
    // }

    // Q2
    // {
    //     string text = "";
    //     char charToSearch;
    //     cout << "\nEnter a string: ";
    //     cin >> text;
    //     cout << "Enter a character to search for: ";
    //     cin >> charToSearch;
    //     Find(text, charToSearch);
    // }

    // Q3
    // {
    //     int rows = 0, cols = 0;
    //     cout << "Enter number of rows: ";
    //     cin >> rows;
    //     cout << "Enter number of columns: ";
    //     cin >> cols;
    //     char **sentence = words_to_sentence(rows, cols);
    //     cout << "\nOutput: " << endl;
    //     for (int i = 0; i < 5; i++)
    //     {
    //         cout << sentence[rows][i];
    //     }
    //     cout << endl;
    //     for (int i = 0; i < 5; i++)
    //     {
    //         cout << sentence[i][cols];
    //     }
    //     cout << endl;
    // }

    // Q4
    {
        MyVector<string> vector1;
        vector1.addElement("1");
        vector1.addElement("1");
        vector1.addElement("1");
        vector1.addElement("1");
        vector1.addElement("1");
        vector1.addElement("5");
        vector1.addElement("1");
        cout << vector1.getElement(50) << endl;
        vector1.changeElement(0, "5");
        vector1.removeElement(5);
        string s1 = vector1[0];
        cout << "s1: " << s1 << endl;
        vector1[0] = "9";
        vector1.print();
    }

    return 0;
}