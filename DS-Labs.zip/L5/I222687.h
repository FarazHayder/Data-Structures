#if !defined(I222687)
#define I222687

#include <iostream>
using namespace std;

class Employee
{
public:
    int ID;
    string NIC;
    double salary;
    double bonus;

    // Constructor
    Employee()
    {
        ID = 0;
        NIC = "";
        salary = 0.0;
        bonus = 0.0;
    }
    // Parametrized Constructor
    Employee(int ID, string NIC, double salary, double bonus)
    {
        this->ID = ID;
        this->NIC = NIC;
        this->salary = salary;
        this->bonus = bonus;
    }
    void Display()
    {
        cout << "Emp ID: " << ID << endl;
        cout << "NIC: " << NIC << endl;
        cout << "Salary: " << salary << endl;
        cout << "Bonus: " << bonus << endl;
    }
};

class Node
{
public:
    Employee data;
    Node *next;
};

class LinkedList
{
private:
    Node *head;

public:
    // Contructor
    LinkedList()
    {
        head = NULL;
    }
    // Clear
    void clear()
    {
        Node *currNode = head, *nextNode = NULL;
        while (currNode != NULL)
        {
            nextNode = currNode->next;
            delete currNode;
            currNode = nextNode;
        }
        head = NULL;
    }
    // Destructor
    ~LinkedList()
    {
        clear();
    }
    // Insertion
    void Insert(const Employee &emp)
    {
        Node *newNode = new Node();
        newNode->data = emp;
        // newNode->data.ID = emp.ID;
        // newNode->data.bonus = emp.bonus;
        // newNode->data.salary = emp.salary;
        // newNode->data.NIC = emp.NIC;
        newNode->next = NULL; /*It will always be the last node;
                                1) If the list is empty, it will be the first node, pointing to NULL.
                                2) If list has some nodes, it will be the last node, still pointing to NULL*/
        if (head == NULL)
        {
            head = newNode;
        }
        else
        {
            Node *currNode = head;
            while (currNode != NULL)
            {
                currNode = currNode->next;
            }
            // currNode->next = newNode;
            newNode->next = currNode;
        }
    }
    // Deletion
    void remove(int id)
    {
        if (isEmpty())
        {
            return;
        }
        Node *currNode = head;
        Node *prevNode = NULL;
        while (currNode != NULL)
        {
            if (currNode->data.ID == id)
            {
                if (currNode == head) // This condition is true if the node to be deleted is the first node and it will be deleted and head will point to the next node
                {
                    head = currNode->next;
                    delete currNode;
                }
                else
                {
                    prevNode->next = currNode->next;
                    delete currNode;
                }
                return;
            }
            prevNode = currNode;
            currNode = currNode->next;
        }
        cout << "Record does not exist" << endl;
    }
    void UpdateSalary(const int &salary, int id)
    {
        if (isEmpty())
        {
            return;
        }
        Node *currNode = head;
        while (currNode != NULL)
        {
            if (currNode->data.ID == id)
            {
                currNode->data.salary = salary;
                return;
            }
            currNode = currNode->next;
        }
        cout << "Record does not exist" << endl;
    }
    void UpdateBonus(const int &bonus, int id)
    {
        if (isEmpty())
        {
            return;
        }
        Node *currNode = head;
        while (currNode != NULL)
        {
            if (currNode->data.ID == id)
            {
                currNode->data.bonus = bonus;
                return;
            }
            currNode = currNode->next;
        }
        cout << "Record does not exist" << endl;
    }
    bool isEmpty()
    {
        if (head == NULL)
            return true;
        else
            return false;
    }
    void display()
    {
        Node *currNode = head;
        while (currNode != NULL)
        {
            currNode->data.Display();
            cout << endl
                 << endl; // For two empty lines
            currNode = currNode->next;
        }
    }
    // Sorting on the basis of salary
    void sort()
    {
        Node *currNode = head;
        Node *nextNode = NULL;
        Employee temp;
        while (currNode != NULL)
        {
            nextNode = currNode->next;
            while (nextNode != NULL)
            {
                if (currNode->data.salary > nextNode->data.salary)
                {
                    temp = currNode->data;
                    currNode->data = nextNode->data;
                    nextNode->data = temp;
                }
                nextNode = nextNode->next;
            }
            currNode = currNode->next;
        }
    }
};

#endif // I222687
