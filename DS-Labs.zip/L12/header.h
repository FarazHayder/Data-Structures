#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include <vector>
#include <conio.h>
using namespace std;

struct Node
{
    string word;
    int occurrenceCount;
    int height;
    Node *left;
    Node *right;

    Node(const string &w) : word(w), occurrenceCount(1), height(0), left(nullptr), right(nullptr) {}
};

struct AVLTree
{
    Node *root;

    AVLTree() : root(nullptr) {}

    int Height(Node *p)
    {
        if (p == nullptr)
            return -1;
        else
            return p->height;
    }

    int Max(int num1, int num2)
    {
        return (num1 > num2) ? num1 : num2;
    }

    Node *SingleRotateWithRight(Node *K1)
    {
        Node *K2;
        K2 = K1->right;
        K1->right = K2->left;
        K2->left = K1;
        K1->height = Max(Height(K1->left), Height(K1->right)) + 1;
        K2->height = Max(Height(K2->right), K1->height) + 1;
        return K2;
    }

    Node *SingleRotateWithLeft(Node *K1)
    {
        Node *K2;
        K2 = K1->left;
        K1->left = K2->right;
        K2->right = K1;
        K1->height = Max(Height(K1->left), Height(K1->right)) + 1;
        K2->height = Max(Height(K2->left), K1->height) + 1;
        return K2;
    }

    Node *DoubleRotateWithLeft(Node *K3)
    {
        K3->left = SingleRotateWithRight(K3->left);
        return SingleRotateWithLeft(K3);
    }

    Node *DoubleRotateWithRight(Node *K1)
    {
        K1->right = SingleRotateWithLeft(K1->right);
        return SingleRotateWithRight(K1);
    }

    Node *Insert(const string &word, Node *T)
    {
        if (T == nullptr)
        {
            T = new Node(word);
        }
        else if (word < T->word)
        {
            T->left = Insert(word, T->left);
            if (Height(T->left) - Height(T->right) == 2)
                if (word < T->left->word)
                    T = SingleRotateWithLeft(T);
                else
                    T = DoubleRotateWithLeft(T);
        }
        else if (word > T->word)
        {
            T->right = Insert(word, T->right);
            if (Height(T->right) - Height(T->left) == 2)
                if (word > T->right->word)
                    T = SingleRotateWithRight(T);
                else
                    T = DoubleRotateWithRight(T);
        }
        else
        {
            // Duplicate word, update occurrence count
            T->occurrenceCount++;
        }

        T->height = Max(Height(T->left), Height(T->right)) + 1;
        return T;
    }

    void Insert(const string &word)
    {
        root = Insert(word, root);
    }

    void InOrderTraversal(Node *node)
    {
        if (node != nullptr)
        {
            InOrderTraversal(node->left);
            cout << node->word << " (Occurrences: " << node->occurrenceCount << ")" << endl;
            InOrderTraversal(node->right);
        }
    }

    bool Search(const string &word)
    {
        Node *currNode = root;
        while (currNode != nullptr)
        {
            if (currNode->word == word)
            {
                cout << "Found: " << word << " (Occurrences: " << currNode->occurrenceCount << ")" << endl;
                return true;
            }
            else if (word < currNode->word)
            {
                currNode = currNode->left;
            }
            else
            {
                currNode = currNode->right;
            }
        }

        cout << "Not Found: " << word << endl;
        return false;
    }

    Node *findMin(Node *node)
    {
        while (node->left != nullptr)
        {
            node = node->left;
        }
        return node;
    }

    Node *DeleteNode(Node *root, const string &word)
    {
        if (root == nullptr)
            return root;

        if (word < root->word)
            root->left = DeleteNode(root->left, word);
        else if (word > root->word)
            root->right = DeleteNode(root->right, word);
        else
        {
            if (root->occurrenceCount > 1)
            {
                // If word has multiple occurrences, decrement occurrence count
                root->occurrenceCount--;
            }
            else
            {
                // If word has only one occurrence or is a unique occurrence, perform deletion
                if (root->left == nullptr)
                {
                    Node *temp = root->right;
                    delete root;
                    return temp;
                }
                else if (root->right == nullptr)
                {
                    Node *temp = root->left;
                    delete root;
                    return temp;
                }

                Node *temp = findMin(root->right);
                root->word = temp->word;
                root->occurrenceCount = temp->occurrenceCount;
                root->right = DeleteNode(root->right, temp->word);
            }
        }

        if (root == nullptr)
            return root;

        root->height = Max(Height(root->left), Height(root->right)) + 1;

        int balance = Height(root->left) - Height(root->right);

        // Left Heavy
        if (balance > 1)
        {
            if (Height(root->left->left) >= Height(root->left->right))
                return SingleRotateWithRight(root);
            else
                return DoubleRotateWithLeft(root);
        }
        // Right Heavy
        if (balance < -1)
        {
            if (Height(root->right->right) >= Height(root->right->left))
                return SingleRotateWithLeft(root);
            else
                return DoubleRotateWithRight(root);
        }

        return root;
    }

    void Delete(const string &word)
    {
        root = DeleteNode(root, word);
    }

    // Function to load a dictionary of words from a text file into the AVL tree
    void LoadDictionary(AVLTree &avlTree, const string &filename)
    {
        ifstream file(filename);
        if (!file.is_open())
        {
            cerr << "Error: Unable to open dictionary file." << endl;
            return;
        }

        string word;
        while (file >> word)
        {
            avlTree.Insert(word);
        }

        file.close();
    }

    // Function to get autocomplete suggestions for a given prefix
    vector<string> Autocomplete(const AVLTree &avlTree, const string &prefix)
    {
        vector<string> suggestions;
        AutocompleteSuggestions(avlTree.root, prefix, suggestions);

        return suggestions;
    }

    // Helper function to traverse the AVL tree and collect autocomplete suggestions
    void AutocompleteSuggestions(Node *node, const string &prefix, vector<string> &suggestions)
    {
        if (node != nullptr)
        {
            if (node->word.compare(0, prefix.length(), prefix) == 0)
            {
                // Word starts with the given prefix, add to suggestions
                suggestions.push_back(node->word);
            }

            if (prefix < node->word)
            {
                AutocompleteSuggestions(node->left, prefix, suggestions);
            }
            else if (prefix > node->word)
            {
                AutocompleteSuggestions(node->right, prefix, suggestions);
            }
            else
            {
                // Prefix matches the current node's word, explore both left and right subtrees
                AutocompleteSuggestions(node->left, prefix, suggestions);
                AutocompleteSuggestions(node->right, prefix, suggestions);
            }
        }
    }

    // Function to pause the program and wait for user input to continue
    void Continue()
    {
        cout << "\nPress any key to continue..." << endl;
        getch();
    }

    void DisplayMenu(AVLTree &avlTree)
    {
        int choice;
        string filename, prefix, deleteWord;
        vector<string> suggestions;
        do
        {
            system("cls"); // For clearing console screen
            cout << "<----- AVL Tree Dictionary Program ----->" << endl;
            cout << "1. Load Dictionary" << endl;
            cout << "2. Autocomplete" << endl;
            cout << "3. Delete Word" << endl;
            cout << "4. Display AVL Tree" << endl;
            cout << "5. Exit" << endl;
            cout << "Enter your choice (1-5): ";
            cin >> choice;
            // choice = getch();
            system("cls"); // For clearing console screen

            switch (choice)
            {
            case 1:
                filename = "dictionary.txt";
                LoadDictionary(avlTree, filename);
                cout << "\nDictionary loaded successfully." << endl;
                Continue();
                break;

            case 2:
                cout << "\nEnter prefix: ";
                cin >> prefix;
                suggestions = Autocomplete(avlTree, prefix);
                cout << "\nAutocomplete Suggestions:" << endl;
                for (const string &word : suggestions)
                {
                    cout << word << endl;
                }
                Continue();
                break;

            case 3:
                cout << "\nEnter word to delete: ";
                cin >> deleteWord;
                avlTree.Delete(deleteWord);
                cout << "\n"
                     << deleteWord << " deleted from dictionary." << endl;
                Continue();
                break;

            case 4:
                avlTree.InOrderTraversal(avlTree.root);
                Continue();
                break;

            case 5:
                cout << "\nExiting program." << endl;
                exit(0);
                Continue();
                break;

            default:
                cout << "\nInvalid choice. Please enter a number between 1 and 5." << endl;
                Continue();
            }
        } while (choice != 5);
    }
} avlTree;