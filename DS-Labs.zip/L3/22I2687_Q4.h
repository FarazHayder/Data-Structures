#include <iostream>
using namespace std;

template <class T>
class MyVector
{
    T *arr;
    int size;
    int elements;

public:
    MyVector()
    {
        this->size = 1;
        arr = new T[size];
        elements = 0;
    }
    MyVector(int size)
    {
        arr = new T[size];
        this->size = size;
        elements = 0;
    }
    void addElement(T value)
    {
        if (elements == size)
        {
            T *newArr = new T[size * 2];
            for (int i = 0; i < size; i++)
            {
                newArr[i] = arr[i];
            }
            delete[] arr;
            arr = nullptr;
            arr = newArr;
            size *= 2;
        }
        arr[elements] = value;
        elements++;
    }
    auto getElement(int index)
    {
        while (index >= size || index >= elements)
        {
            throw out_of_range("Index out of bounds");
        }
        for (int i = 0; i < size; i++)
        {
            if (i == index)
            {
                return arr[i];
            }
        }
    }
    void changeElement(int index, T value)
    {
        while (index >= size || index >= elements)
        {
            throw out_of_range("Index out of bounds");
        }
        for (int i = 0; i < size; i++)
        {
            if (i == index)
            {
                arr[i] = value;
            }
        }
    }
    void removeElement(int index)
    {
        while (index >= size || index >= elements)
        {
            throw out_of_range("Index out of bounds");
        }
        T *newArr = new T[size * 2];
        for (int i = 0; i < elements; i++)
        {
            if (i != index)
            {
                newArr[i] = arr[i];
            }
        }
        delete[] arr;
        arr = nullptr;
        arr = newArr;
    }
    void print()
    {
        for (int i = 0; i < size; i++)
        {
            cout << arr[i];
        }
    }
    T &operator[](int index)
    {
        // Check if index is within bounds
        if (index >= size)
        {
            throw out_of_range("Index out of bounds");
        }

        // Return a reference to the element at index
        return arr[index];
    }
};
