#include "methods.h"

int main()
{
    RouteOptimizationSystem cityMap;

    int choice;
    do
    {
        printMenu();
        cin >> choice;

        switch (choice)
        {
        case 1:
        {
            int locationID;
            cout << "Enter Location ID: ";
            cin >> locationID;
            cityMap.addLocation(locationID);
            Continue();
            break;
        }
        case 2:
        {
            int source, destination, length;
            cout << "Enter Source Location ID: ";
            cin >> source;
            cout << "Enter Destination Location ID: ";
            cin >> destination;
            cout << "Enter Length: ";
            cin >> length;
            cityMap.addRoute(source, destination, length);
            Continue();
            break;
        }
        case 3:
        {
            int start, end;
            cout << "Enter Start Location ID: ";
            cin >> start;
            cout << "Enter End Location ID: ";
            cin >> end;
            cityMap.findShortestPath(start, end);
            Continue();
            break;
        }
        case 4:
            exit(0);
            break;
        }
    } while (choice != 4);

    return 0;
}

void preorder(Node *root)
{
    if (root == NULL)
        return;

    cout << root->value;
    preorder(root->left);
    preorder(root->right);
}