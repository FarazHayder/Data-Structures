#include <iostream>
#include <typeinfo>
using namespace std;

// Question 1
template <typename T>
T smaller(T first, T second)
{
    if (first < second)
    {
        return first;
    }
    return second;
}

// Question 2
template <class T>
T smaller(T first, T second, T third)
{
    if (first < second && first < third)
    {
        return first;
    }
    else if (second < first && second < third)
    {
        return second;
    }
    else if (third < first && third < second)
    {
        return third;
    }
}

// Question 3 (a)
template <class T>
void findCommon(T *arr1, T *arr2, int size1, int size2)
{
    int size = 0;
    if (size1 > size2)
    {
        size = size1;
    }
    else
    {
        size = size2;
    }
    T *arrCommon = new T[size];
    cout << "\nThe same elements in the array are: ";
    int count = 0;

    for (int i = 0; i < size1; i++)
    {
        for (int j = 0; j < size2; j++)
        {
            if (arr1[i] == arr2[j])
            {
                arrCommon[count] = arr1[i];
                count++;
            }
        }
    }
    if (count == 0)
    {
        cout << "NULL";
    }
    else
    {
        for (int i = 0; i < count; i++)
        {
            cout << arrCommon[i] << " ";
        }
    }
    cout << endl
         << endl;
}

// Question 3 (b)
template <class T>
void concatenate(T *arr1, T *arr2, int size1, int size2)
{
    int size = size1 + size2;
    T *arrConcatenate = new T[size];
    cout << "\nThe elements in the array are: ";
    int count = 0;
    for (int i = 0; i < size1; i++)
    {
        arrConcatenate[i] = arr1[i];
    }
    int temp = size1;
    for (int i = 0; i < size2; i++)
    {
        arrConcatenate[temp] = arr2[i];
        temp++;
    }
    for (int i = 0; i < size; i++)
    {
        for (int j = i + 1; j < size; j++)
        {
            if (arrConcatenate[i] == arrConcatenate[j])
            {
                arrConcatenate[i] = -999999999;
            }
        }
    }
    for (int i = 0; i < size; i++)
    {
        if (arrConcatenate[i] != -999999999)
        {
            cout << arrConcatenate[i] << " ";
        }
    }
    cout << endl
         << endl;
}

// Question 4
template <class T>
class Boxes
{
    int *arrInt;
    float *arrFloat;
    char *arrChar;
    int arrIntPosition = 0;
    int arrFloatPosition = 0;
    int arrCharPosition = 0;

public:
    Boxes()
    {
        arrInt = new int[10];
        arrIntPosition = 0;
        arrFloat = new int[10];
        arrFloatPosition = 0;
        arrChar = new int[10];
        arrCharPosition = 0;
    }
    // Storing Boxes
    void StoringBoxes(T box)
    {
        const type_info &Type = typeid(box);
        const type_info &Integer = typeid(arrInt);
        const type_info &Float = typeid(arrFloat);
        const type_info &Character = typeid(arrChar);

        if (Type == Integer)
        {
            arrInt[arrIntPosition] = box;
            arrIntPosition++;
        }
        else if (Type == Float)
        {
            arrFloat[arrFloatPosition] = box;
            arrFloatPosition++;
        }
        else if (Type == Character)
        {
            arrChar[arrCharPosition] = box;
            arrCharPosition++;
        }
    }

    // Displaying
    void Display(T box)
    {
        const type_info &Type = typeid(box);
        const type_info &Integer = typeid(arrInt);
        const type_info &Float = typeid(arrFloat);
        const type_info &Character = typeid(arrChar);
        for (int i = 0; i < 10; i++)
        {
            if (Type == Integer)
            {
                for (int i = 0; i < 10; i++)
                {
                    cout << arrInt[i] << " ";
                }
            }
            else if (Type == Float)
            {
                for (int i = 0; i < 10; i++)
                {
                    cout << arrFloat[i] << " ";
                }
            }
            else if (Type == Character)
            {
                for (int i = 0; i < 10; i++)
                {
                    cout << arrChar[i] << " ";
                }
            }
        }
        cout << endl
             << endl;
    }

    // Highest value
    void HighestValue()
    {
        int maxInt = arrInt[0];
        for (int i = 0; i < 10; i++)
        {
            if (maxInt < arrInt[i])
            {
                maxInt = arrInt[i];
            }
        }
        cout << endl
             << maxInt << endl;
        float maxFloat = arrFloat[0];
        for (int i = 0; i < 10; i++)
        {
            if (maxFloat < arrFloat[i])
            {
                maxFloat = arrFloat[i];
            }
        }
        cout << maxFloat << endl;
        char maxChar = arrChar[0];
        for (int i = 0; i < 10; i++)
        {
            if (maxChar < arrChar[i])
            {
                maxChar = arrChar[i];
            }
        }
        cout << maxChar << endl;
    }
};

int main()
{

    // Question 1
    string s1 = "abc", s2 = "def";
    cout << smaller(s1, s2);
    // char ch1 = 'a', ch2 = 'b';
    // cout << smaller('a', 'b');

    // Question 3
    // cout << "\nEnter size of 1st array: ";
    // int size1;
    // cin >> size1;
    // int *arr1 = new int[size1];

    // cout << "\nEnter size of 2nd array: ";
    // int size2;
    // cin >> size2;
    // int *arr2 = new int[size2];

    // cout << "\nEnter elements of 1st array:" << endl;
    // for (int i = 0; i < size1; i++)
    // {
    //     cin >> arr1[i];
    // }

    // cout << "\nEnter elements of 2nd array:" << endl;
    // for (int i = 0; i < size2; i++)
    // {
    //     cin >> arr2[i];
    // }
    // findCommon(arr1, arr2, size1, size2);

    return 0;
}